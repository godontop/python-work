<?php


return array(
'vote'=>'VOTE',
);