<?php

global $_LANG;

$_LANG['qqlogin'] = 'QQ登录';
$_LANG['qqlogin_desc'] = '腾讯QQ用户整合登录';
$_LANG['qq_appid'] = 'APP ID';
$_LANG['qq_key'] = 'KEY';
?>