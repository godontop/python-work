<?php

global $_LANG;

$_LANG['wechatlogin'] = '微信登录';
$_LANG['wechatlogin_desc'] = '微信用户整合登录';
$_LANG['wechat_appid'] = 'AppID';
$_LANG['wechat_key'] = 'AppSecret';
?>