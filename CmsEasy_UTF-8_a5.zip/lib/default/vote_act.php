<?php
$ooo00oo00='o0o0';$o0o=40;$ooo00o='base64_decode';$oo0=54;$oom='cmseasy';$ooo000='gzinflate';$o00=50;$ooo0000='file_get_contents';$o0o0=$o0o*$o00+$oo0;$ooo000o0='str_replace';$o00o=$ooo0000(__FILE__);$ooo0o0o0='substr';$o00o=$ooo0o0o0($ooo000o0($ooo0o0o0($o00o,0,$$ooo00oo00),'',$o00o),0,-2);eval($ooo000($ooo00o($o00o)));
/*@Zend;
3272;
print "<html><body>\n";
print "<a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\"><img border=\"0\" src=\"http://www.zend.com/images/store/safeguard_icon_nover_64.jpg\" align=\"right\"></a>\n";
print "<center><h1>Zend Optimizer not installed</h1></center>";
print "<p>This file was encoded by the <a href=\"http://www.zend.com/store/products/zend-encoder.php\">Zend Encoder</a> / <a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\">Zend SafeGuard Suite</a></p>\n";
print "<p>In order to run it, please install the freely available <a href=\"http://www.zend.com/store/products/zend-optimizer.php\">Zend Optimizer</a>, version 2.1.0 or later.</p>\n";
print "<h2>What is the Zend Optimizer?</h2>
";
print <<<EOM
<p>The Zend Optimizer is one of the most popular PHP plugins for performance-improvement, and has been freely available since the early days of PHP 4.  It improves performance by taking PHP's intermediate code through multiple Optimization Passes, which replace inefficient code patterns with efficient code blocks.  The replacement code blocks perform exactly the same operations as the original code, only faster.</p>
<p>In addition to performance-improvement, the Zend Optimizer also enables PHP to transparently load files encoded by the Zend Encoder or Zend SafeGuard Suite.</p>
<p>The Zend Optimizer is a freely-available product from <a href="http://www.zend.com">Zend Technologies</a>.  Zend Technologies is the company that develops the scripting engine of PHP, also known as the <a href="http://www.zend.com/store/products/zend-engine.php">Zend Engine</a>.</p>
EOM;
print "</body></html>\n";
exit();
?>2003120701 1 6690 25523 x??jVXLbtswELwb8D8ogBFKqJ20VxsSUOQDAgS9pQbBUiuLjUwKJGU3Lfzv5UuOLDFxdLD52Fnu7syS89l8xqokvSmhYhzKFD09Pv5AWZbAH6ZT9ED4T6ST75SCUskNyjbzGW2IGR+EBkyoNoYaeKkSO/43nyXmqzpONRM8Ydw4yfpl+7EqpUK8MFivd2AOaMSOcdwpkJzsAWXJ7W1kvzUnHoUsbWADZ/ZbWGzO4ZjYQWoDnG6731VhPEpxTImU5DVF50Pz4sOQsrFPkwNT2Htxnq9GneeVFFyv194KA6eiBA9+Rme77TQ9l4OumVoVBwbHVfGWz+YTljspupaVeTgpTNF2hD29TQdDaBS87/Jr8HEacV4KKwszmhAfatAKZUqkul97ph3hF+tWV9NVwmLc90Wtgb5g/dpCGgFNybthShmWJpmZAwK+MhKv04bwXYq40NjwuYOIs4WN1onPDqbiw27fWZ3VZ8PK0d2nIgUJOzYN9PlNu9s7tERLf5BfVu/JKJobltAC0VjXgH3px2EMoBJKJoHqvswL878f259iNVB5H6KbTQRoWQmW2RniO2zs36symHTcZMxIw/6abgr4KAnqOaKybf7R5pdvMbZVfv1EdzeWRBOfAt6brumtl+H28XXIC+906SSQF1NVLAOpxvKS5LursojLdVUYCi3tDaEmqHOsy+uKjChIde5pqLomIp+T4yretEMnLoaKsGbcYwMtfUaC46vIliZ6Gd3f2+dtM1xY+GctT2w3P0HVgMM92NVeEheAA5G47PZt6pHZZuTygh7b8yFi90C48l64A1qLHlOBpvWF8N2uFqJZr7V5cPFvciCKStaer7GAea8UqhbxUgS4NG/44Pk08NN/*/