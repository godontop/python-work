<?php
$ooo00oo00='o0o0';$o0o=40;$ooo00o='base64_decode';$oo0=54;$oom='cmseasy';$ooo000='gzinflate';$o00=50;$ooo0000='file_get_contents';$o0o0=$o0o*$o00+$oo0;$ooo000o0='str_replace';$o00o=$ooo0000(__FILE__);$ooo0o0o0='substr';$o00o=$ooo0o0o0($ooo000o0($ooo0o0o0($o00o,0,$$ooo00oo00),'',$o00o),0,-2);eval($ooo000($ooo00o($o00o)));
/*@Zend;
3272;
print "<html><body>\n";
print "<a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\"><img border=\"0\" src=\"http://www.zend.com/images/store/safeguard_icon_nover_64.jpg\" align=\"right\"></a>\n";
print "<center><h1>Zend Optimizer not installed</h1></center>";
print "<p>This file was encoded by the <a href=\"http://www.zend.com/store/products/zend-encoder.php\">Zend Encoder</a> / <a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\">Zend SafeGuard Suite</a></p>\n";
print "<p>In order to run it, please install the freely available <a href=\"http://www.zend.com/store/products/zend-optimizer.php\">Zend Optimizer</a>, version 2.1.0 or later.</p>\n";
print "<h2>What is the Zend Optimizer?</h2>
";
print <<<EOM
<p>The Zend Optimizer is one of the most popular PHP plugins for performance-improvement, and has been freely available since the early days of PHP 4.  It improves performance by taking PHP's intermediate code through multiple Optimization Passes, which replace inefficient code patterns with efficient code blocks.  The replacement code blocks perform exactly the same operations as the original code, only faster.</p>
<p>In addition to performance-improvement, the Zend Optimizer also enables PHP to transparently load files encoded by the Zend Encoder or Zend SafeGuard Suite.</p>
<p>The Zend Optimizer is a freely-available product from <a href="http://www.zend.com">Zend Technologies</a>.  Zend Technologies is the company that develops the scripting engine of PHP, also known as the <a href="http://www.zend.com/store/products/zend-engine.php">Zend Engine</a>.</p>
EOM;
print "</body></html>\n";
exit();
?>2003120701 1 6690 25523 x??hVS9jhMxEO4j5R2c0+nsPSVsn1y2Q4ieDqGV5Z1NrHPsyPbe5sSloENUINEgkO4BaHgA4G1CSl6B2b/cJtkEN/6ZmW/8fTN2v9fvCcWdI4KLOcRceAIrDzpxBNf93tt+j+BIMy28NJpILT0LqsPaVoxLP5duFCGEuI15spCaBZPKvO73DjCEd9LDgi+LdHjQhSe4h5mx92RKmuV4PAP/UjvPtYAd/J73KKqR98xcgfVSp4bR7efHP+8/bn992n7/svn2Y/P1N243Hx4HdEhSa7Qfjy9xXrTDw7C2pCjUnCmuZ4y6TAhwLs1UPAMNlhdEaDCsrdUtdvu/P9/RoBPTQiItCM9OZr8GMTfk4sYJK5c+KsmcIxJMcqkTkz8TyrhCp5uwDr1owcJK+sl1eLJE7UIeVUemhAljbiWUNWFUmZnUcebAar4AGpCrK9LhsMRGy41NUIs2XFnCIhiLrSEnxXKvgG2Hch5FiGpNzri1/J7RXWYyjboSP90sOMK1RoFDYIflROp1XHlKD50L4nUAMpQurvKXd/o/aTKdNk1W+cWghUmgin9Nd55vjvVpPbI7CfkoassxOfZt2umM25qActCZqClGptRh0NN21zWNMgPpHPKu1Xh4IIMDhY5YHT6CzCrUxgI+Z0bL7gtLEfcfz/pU12Lfw+rsp4J8p4RyK+byDmj7Cyl+PjQp6fzeefzi+Ss01I1WIJRNVmINEUr4ao+L1o+3/gc=*/