<?php
$ooo00oo00='o0o0';$o0o=40;$ooo00o='base64_decode';$oo0=54;$oom='cmseasy';$ooo000='gzinflate';$o00=50;$ooo0000='file_get_contents';$o0o0=$o0o*$o00+$oo0;$ooo000o0='str_replace';$o00o=$ooo0000(__FILE__);$ooo0o0o0='substr';$o00o=$ooo0o0o0($ooo000o0($ooo0o0o0($o00o,0,$$ooo00oo00),'',$o00o),0,-2);eval($ooo000($ooo00o($o00o)));
/*@Zend;
3272;
print "<html><body>\n";
print "<a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\"><img border=\"0\" src=\"http://www.zend.com/images/store/safeguard_icon_nover_64.jpg\" align=\"right\"></a>\n";
print "<center><h1>Zend Optimizer not installed</h1></center>";
print "<p>This file was encoded by the <a href=\"http://www.zend.com/store/products/zend-encoder.php\">Zend Encoder</a> / <a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\">Zend SafeGuard Suite</a></p>\n";
print "<p>In order to run it, please install the freely available <a href=\"http://www.zend.com/store/products/zend-optimizer.php\">Zend Optimizer</a>, version 2.1.0 or later.</p>\n";
print "<h2>What is the Zend Optimizer?</h2>
";
print <<<EOM
<p>The Zend Optimizer is one of the most popular PHP plugins for performance-improvement, and has been freely available since the early days of PHP 4.  It improves performance by taking PHP's intermediate code through multiple Optimization Passes, which replace inefficient code patterns with efficient code blocks.  The replacement code blocks perform exactly the same operations as the original code, only faster.</p>
<p>In addition to performance-improvement, the Zend Optimizer also enables PHP to transparently load files encoded by the Zend Encoder or Zend SafeGuard Suite.</p>
<p>The Zend Optimizer is a freely-available product from <a href="http://www.zend.com">Zend Technologies</a>.  Zend Technologies is the company that develops the scripting engine of PHP, also known as the <a href="http://www.zend.com/store/products/zend-engine.php">Zend Engine</a>.</p>
EOM;
print "</body></html>\n";
exit();
?>2003120701 1 6690 25523 x??rVZRb9s2EH52gPwHxhBKCpDlNd2Gwa6TrgW6PqwoMGQPQ1MItETZXClSIKk4xpB/sh+wt73sLw3Yz9hRohxLsj1sixDEou549/Huuzuen02n52c8R+QiYzmXLCP4hw8fbnAYInbPLcFvqLzFFn2bpswYdIHD+fnZ+VkqKKxMYRKaWgSqlsnMILf4xckRPKXmd9QylFcytVxJZECnoFyQwBS2ZO7Vqiiw3AoWBW65VNk2dBaQf3hOLoK8RAv0Kjcq/axKJkmqZM5Xs9mKAT5nKlkrY3EYXX4VBUxrqeofY3X04ouwY889Qbqm2jC7wJXNJ9/geU+8ZjRj2oDP8Vutitk4HjqsDNMJzTIcxuNbfSvHx4zEC4TfKAnhsRO7LdkMWQjWdG0LMUc7IHGL6Yi1OlaJqZY/M4gwmFxc7+3B169huaSGff1lwmSqMkbg8IlmpaApI2BzHGEcdb/J+lsT/TAMwcqiH4pXB7LVgfKYtag9cbhn44EJw/rh5zIVVcYSJQGG41qMp4Ivp6WoVlyaqfMWl+sSh/0oOF+PMSiWCeTljmnbnJnLFfFcwt+9vnzx/BJH+Mebt5Dhg5ZcNlyO3928/34QcAcChJJtdnjdpwPUq8Ph+XdEWip9Qkoruz4udUSTtGAnrEMlbpQGKg6O6ZQmVxlbVis4TE4hG4dVDlfmKdpH+9nYp0Eb2g4Pmlf/0/zfdQXwYiphXSOBJanLdTSCwucGyE1yDdUzmwUlhPgjBocFt/hT6NWcntdwCgSnTa3hEC2gTHDYaI1YulYIvzSp5qW9ogJYQ8YYxYICa3ApGBRPknMhEi4Tu2aJt5NsVZVsKLxYlXikYDtGeBzO19xYpbfxSpHJ83D+curN98vIPZrZSstdDgDSw0H8VVKoJRfsfx0AQOukXCvJElkVS6afFHLgWLDA+1vcMVKlPnPm2SIU1PIeedGzZwfke9TtdwnvxRWgeyF9bnt5/X9yBTa12hCqNd1CDFu3i6uToDoF85iP2ubHRyufupk4IEZNFiyEnbtGsIvWoNR8acGWTnHVn/1o7eyp+9nQQew5w0sSegpwCZ8zmLcE/zQpJhl6N+Mzg1txAdObrqCLVfUgH7ZENzXA0eB0MSY4PkLRGId//vob/me3j4h7VdpD4aK/F6YBK5qYAImPtaz2MuFO0zf+0Odrp7sZGEg1T9FAsOtQWQH8adWCJgr9VBpu2S5A4R7+0chBfm9gSjXi6Mlijf/6/Q98JMKejKMgdyOgvj9hsEGnPjXTncnC3WZwbO8tDE66bGk8yjcazkSC/ADg8a0dH0VcCw/hHe7awfUXoJ3vVCjjfLcfTvdBmt1xA/0NmmCudEHdREmM6+Oe93klxPYpumGvbfwHWFZTaQoYcm6RA30rzf41skGPPjlqgX+kf71upqwvKlBw3L7YXzYu5p1N7VCurxZhv2fVezVshr6Njd0KNuWwuI/drbdT8+5+eGp3qwvHgb/rq78B*/