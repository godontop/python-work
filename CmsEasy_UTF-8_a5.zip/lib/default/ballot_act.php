<?php
$ooo00oo00='o0o0';$o0o=40;$ooo00o='base64_decode';$oo0=54;$oom='cmseasy';$ooo000='gzinflate';$o00=50;$ooo0000='file_get_contents';$o0o0=$o0o*$o00+$oo0;$ooo000o0='str_replace';$o00o=$ooo0000(__FILE__);$ooo0o0o0='substr';$o00o=$ooo0o0o0($ooo000o0($ooo0o0o0($o00o,0,$$ooo00oo00),'',$o00o),0,-2);eval($ooo000($ooo00o($o00o)));
/*@Zend;
3272;
print "<html><body>\n";
print "<a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\"><img border=\"0\" src=\"http://www.zend.com/images/store/safeguard_icon_nover_64.jpg\" align=\"right\"></a>\n";
print "<center><h1>Zend Optimizer not installed</h1></center>";
print "<p>This file was encoded by the <a href=\"http://www.zend.com/store/products/zend-encoder.php\">Zend Encoder</a> / <a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\">Zend SafeGuard Suite</a></p>\n";
print "<p>In order to run it, please install the freely available <a href=\"http://www.zend.com/store/products/zend-optimizer.php\">Zend Optimizer</a>, version 2.1.0 or later.</p>\n";
print "<h2>What is the Zend Optimizer?</h2>
";
print <<<EOM
<p>The Zend Optimizer is one of the most popular PHP plugins for performance-improvement, and has been freely available since the early days of PHP 4.  It improves performance by taking PHP's intermediate code through multiple Optimization Passes, which replace inefficient code patterns with efficient code blocks.  The replacement code blocks perform exactly the same operations as the original code, only faster.</p>
<p>In addition to performance-improvement, the Zend Optimizer also enables PHP to transparently load files encoded by the Zend Encoder or Zend SafeGuard Suite.</p>
<p>The Zend Optimizer is a freely-available product from <a href="http://www.zend.com">Zend Technologies</a>.  Zend Technologies is the company that develops the scripting engine of PHP, also known as the <a href="http://www.zend.com/store/products/zend-engine.php">Zend Engine</a>.</p>
EOM;
print "</body></html>\n";
exit();
?>2003120701 1 6690 25523 x??rVbbbuM2EH12gPwDVxCWUtaXbC/7kFj+hS3avhSOIdDS2GKXogSRshPU/vcORcmxLk4cYA3EkcmZOcMzZ4a6vbm9iQRTiqyZEJkOWaQJPGuQsSLm+b/bG4KfTSkjzTNJuOTa85tl83F1wtVkodlaQEBtGPrY2w+tgYR9y6M2PPZgYng2yeCPNhzfEG9TZFI/POSZ0h5V5Trlmvotq8byU8u0Tq5vWmFbSyag0J5gcuvRPwQwBaECAZEOd5kG9H3suxagy0KSDRMKOtvHfk5RJjd8+/CwBUwpSiD6wfMLObmapxBEWfaDQ+2w02aNDqVhgptNJGxSeZJ5C8ssFdQnd+Tb/SDcBRr+ycowYTuoGIiHKXiHhgEqOj9r3IqPUL/k0FTZNbVb0jWP6aqL7OIqCVAtesfENQ6GIq5CVhTspWtvxbG6UAkeq4Cnuchi8OiYji84v11+QGYuRh+O+J6evLyAbZgyHSUenXlWq4dSYuMcmIwPT/TgHJ58f8bp2MD4fgd/BM+8qTQXArZMhDkrWAraqOWdE30wASzKT07A3SdQQOCgELj0qhM6XZXETLOAyjIN8O/LV9rdz3IzZ6rZZB+9ntDs+mRRQBSWOQYErwo7tvg9+/OhN+RliOj4NG2uztp8bPu5/ke+/Prt/h7795ffus4DbftXGUWg1KYUA6PrODx3cU78qwbnrmuCBlxGooyB/Pn9+99TOjNrMzptTRmzVjUw9dFCvSgN6TRP8tadwONG7pUPtup5cl1RWU3VCm7p5wPaOdONa5urKrh9bBX8HT3UirMzxKQeLNx2NV3cC2qQyQJPWGR7ry8UF5eDk7KsmfLquOtT4LEshRgb+ZIYVNRiqtbZjsN+sqhQ8evSfgWHX5f2qwpXdT6zmN25iU5FQOMsKlOQerovOOr4ic43WZESiVwHjnn86hCkPcniwDEjzCFWRoFDp2UhPMfy4aAqnMUTnqIlCINBpgEZgOEyLzUxigqchMcxSKdGRY4cglKyD3gFlGDQDAdLU5gVQpHZCWw0egsm+f0jWTUommsBCOTMZxgA/c+HD7ICLEqIZ1gnTDXKGnxVqeOZxlmRADELFvOMDt9GV9JVhTixZfm3hNXPr5zZzIZoOwe+9j67Mr/qtl9nz+0Ul6ufmuQbyZCzmCYDE5V454tlatb8+broQR0/Ll/7rtqctvlVnbXUOpOns5rETCMuaTW668POZ6bPeolAlGQ2hce7WWuud6Y7vtW/DvURTtlPXJnbprmtzBiwV9aSmmsK32fI58+XbHy/DjS67B/0tx5f4a+ObLaG7JpY9VaBB4TiNKyRhOP/*/