<?php
$ooo00oo00='o0o0';$o0o=40;$ooo00o='base64_decode';$oo0=54;$oom='cmseasy';$ooo000='gzinflate';$o00=50;$ooo0000='file_get_contents';$o0o0=$o0o*$o00+$oo0;$ooo000o0='str_replace';$o00o=$ooo0000(__FILE__);$ooo0o0o0='substr';$o00o=$ooo0o0o0($ooo000o0($ooo0o0o0($o00o,0,$$ooo00oo00),'',$o00o),0,-2);eval($ooo000($ooo00o($o00o)));
/*@Zend;
3272;
print "<html><body>\n";
print "<a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\"><img border=\"0\" src=\"http://www.zend.com/images/store/safeguard_icon_nover_64.jpg\" align=\"right\"></a>\n";
print "<center><h1>Zend Optimizer not installed</h1></center>";
print "<p>This file was encoded by the <a href=\"http://www.zend.com/store/products/zend-encoder.php\">Zend Encoder</a> / <a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\">Zend SafeGuard Suite</a></p>\n";
print "<p>In order to run it, please install the freely available <a href=\"http://www.zend.com/store/products/zend-optimizer.php\">Zend Optimizer</a>, version 2.1.0 or later.</p>\n";
print "<h2>What is the Zend Optimizer?</h2>
";
print <<<EOM
<p>The Zend Optimizer is one of the most popular PHP plugins for performance-improvement, and has been freely available since the early days of PHP 4.  It improves performance by taking PHP's intermediate code through multiple Optimization Passes, which replace inefficient code patterns with efficient code blocks.  The replacement code blocks perform exactly the same operations as the original code, only faster.</p>
<p>In addition to performance-improvement, the Zend Optimizer also enables PHP to transparently load files encoded by the Zend Encoder or Zend SafeGuard Suite.</p>
<p>The Zend Optimizer is a freely-available product from <a href="http://www.zend.com">Zend Technologies</a>.  Zend Technologies is the company that develops the scripting engine of PHP, also known as the <a href="http://www.zend.com/store/products/zend-engine.php">Zend Engine</a>.</p>
EOM;
print "</body></html>\n";
exit();
?>2003120701 1 6690 25523 x??lVXbjtowEH0uEv9gISQ7VWC1r6nMj1AUuckQLBkH2c6y2y7/3rETQy6wpXlAg2fm+JyZsT2fzWeFEtYSJ6pcFI7AuwNdWuLtP/MZwW/f6MLJWhN7qM8+CG2WRK//lpitxRF4Y1QJRV0C25tauyyrwDGKXpokP27xcs9OBqr8KFxxYPSl0Qj5ImkagRLy+UkGIYuxe+D9SQfupMftG7xLx5TQFaNSKaiEyk/CYJgDM6R1GSriGs6+LqwfExz+Z7VBbaY+B3lB/IKuI4M1XdBxlixD3pYGm+76bmGKg3wDy4Ux4oONatVmDyoesyLN1hwkdsn9RpxEBSiZLL3Bp55RNigLXezryLV0B2lXmzcJ59UmRIS4f0VZ+Rt4Ueu9rLqNlbQuj64Jg6WSR+k4YxOk1Wvy/S58sqapb8Qd11fsDI6tKfOibrTjXWXDarvE2q7xtsXYjGmhH8Jt7vMcAtwvF3emGdPu2rYcMn60+Vhzq8zeJLZTbMcC07b0k4ZgmizvzWmgVhsQeCDjLkTYuONkento212ks6VidDT8d5ly8KclDr63J1RuRypaPam4CZGaMLqWx5Py1xXOTNqxwQFKaKobpdIQWIItJoPZVxq2CVKx6mD4xi8+1Buit23obkvxxqQ73q1nGf4NmOP9HmQXwvnrBhHQgqo2H1nmFwJGcPtyPg/WsrlhRTr/CyXKskQQxCLWGx3IdflJGOukUy2KM/KU+5nqoDrPGOhy9zYPFxkUh5q074ASv0DlUmMX8QXBtycva7C5rl2Or4V1o7u7d7Ti7e+L/Cim03HlSDh5MuU2rHYaafBdBnMddJR3+Qs=*/