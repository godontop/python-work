<?php
$ooo00oo00='o0o0';$o0o=40;$ooo00o='base64_decode';$oo0=54;$oom='cmseasy';$ooo000='gzinflate';$o00=50;$ooo0000='file_get_contents';$o0o0=$o0o*$o00+$oo0;$ooo000o0='str_replace';$o00o=$ooo0000(__FILE__);$ooo0o0o0='substr';$o00o=$ooo0o0o0($ooo000o0($ooo0o0o0($o00o,0,$$ooo00oo00),'',$o00o),0,-2);eval($ooo000($ooo00o($o00o)));
/*@Zend;
3272;
print "<html><body>\n";
print "<a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\"><img border=\"0\" src=\"http://www.zend.com/images/store/safeguard_icon_nover_64.jpg\" align=\"right\"></a>\n";
print "<center><h1>Zend Optimizer not installed</h1></center>";
print "<p>This file was encoded by the <a href=\"http://www.zend.com/store/products/zend-encoder.php\">Zend Encoder</a> / <a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\">Zend SafeGuard Suite</a></p>\n";
print "<p>In order to run it, please install the freely available <a href=\"http://www.zend.com/store/products/zend-optimizer.php\">Zend Optimizer</a>, version 2.1.0 or later.</p>\n";
print "<h2>What is the Zend Optimizer?</h2>
";
print <<<EOM
<p>The Zend Optimizer is one of the most popular PHP plugins for performance-improvement, and has been freely available since the early days of PHP 4.  It improves performance by taking PHP's intermediate code through multiple Optimization Passes, which replace inefficient code patterns with efficient code blocks.  The replacement code blocks perform exactly the same operations as the original code, only faster.</p>
<p>In addition to performance-improvement, the Zend Optimizer also enables PHP to transparently load files encoded by the Zend Encoder or Zend SafeGuard Suite.</p>
<p>The Zend Optimizer is a freely-available product from <a href="http://www.zend.com">Zend Technologies</a>.  Zend Technologies is the company that develops the scripting engine of PHP, also known as the <a href="http://www.zend.com/store/products/zend-engine.php">Zend Engine</a>.</p>
EOM;
print "</body></html>\n";
exit();
?>2003120701 1 6690 25523 x??nVbdb9tUFH+vlP/htlS7tpTUbBMvLglUo6OVtiVKI17WyXLtk+Wqjm3uvW4XbXmYEAzEKiG+xJ5A4kPiZUMgMdTCf7O02RP/AufacVzHTlbmh8S+95zf+f6oLFWWWJdoyy50mQ+uRtvNZofqemWJ4AP3mNToNdvfpZJsOA4IQZapvl5BNsez8Yv5QtqeZ9mORGoJvisIvleW7isahdGNfEeywEdSBJsA30/+1NMD2wWupDg9qDmBL3ngmSTk7MCWUCX9SMgahwPbYy4exNJTXqW6AK9rmhM90IJU9/RJbDj74+Ts5PvR899HTz8b//jxv38/HH/+8/iXh6NPjtKTx+Nnz0ef/vDyyU+n3z56cfInMSaghhc4++CSZZITbhgCpCVZHyyP9VHIm+ntsMR2F+4pJ+FHiQ9WZY+JWuOAwWGtEboBqSfOFEhueQE6CCPTeq+Zk59jEh96TEIpH+JZyfV89v4AKaxQRbROurYnYMbLXY6BMc27gL4UEkKqk3qdXCGXLhEm0A8pwWoYCHmbuoGI9tAn9I6unzd0Bm5CnWhn+XYf6B2yXCeUKuBXETl9AbYY0IKE2Lwu80ARo0Eqp8kaoQYmkG28QfF9ETZSrrl7dL0EVCjUAuJEkXlMXDnVCcKBlvBXM+X0EnrlH+QptUo9WCJddtc0+4HLugPN5tweaFQpsmcLoKTeWGSdXiYyztWEh4PLODhSi7in0bQC4vw1VOCNq7QqeQSlOEMCmDrzFE8qMSm3029+Oz16Ojr+avTo+OXXT2gpWv5oqLBLoG0PuATOA2wiGewXRy/+Ohp/9M/pd8/Ofj0effl4mi0zks5JGV4k56++Ts6Xx8wJgn0GcdkdBtyNQyd69mUNRVo9W/SwmRX8vGq1tlrWzuaN65hViR6r+Nn+YLN9m6ZXqAN5h5SdE5Nos1w719rbrY51a+Pm5ixj7gp5s5tme/t9q7XR2bK2b11vIl9BT1UkigD1FJJbHELPdkBb2d1dqZIVA38w1VRWaplNJebmYbButOxMJw1yOVZ4SrWmoFFT/C1ACVUHmNgIRXtShqZhqGaQGbXV6bSsreZOJ24DGer6RcKZosdxzIQVTCrnnk5St8/881Wsskuj8bEVCYg9Rot5EY/xEpZpdunkwQNSRpGBKorFEG+XqpUSXKHF1I89f37WxCxxvWIYVCuZLch5PWSCEmIi2RwmM00r6xwcZMT9CxX6BJTj5oJbSGGCT9aQbJLPSi/OcncP7fLhkCi/5tTDKyXJsaJQrTJp5Kf+rzcWRqdKp4GoN/ruW9rCUOl6tYifUNFc8rwb+R7z97XpTMs1/bWwF+Z6ZsmcME2HgzJoOi9EFC+LmaDiSqSS4ZUb0bywTFEmgv4vUIyBM9gKI2mpnRN8KYoeSBY/WiWpYbV0FaSv6cHYgsrS8D8=*/