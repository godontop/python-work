<?php
$ooo00oo00='o0o0';$o0o=40;$ooo00o='base64_decode';$oo0=54;$oom='cmseasy';$ooo000='gzinflate';$o00=50;$ooo0000='file_get_contents';$o0o0=$o0o*$o00+$oo0;$ooo000o0='str_replace';$o00o=$ooo0000(__FILE__);$ooo0o0o0='substr';$o00o=$ooo0o0o0($ooo000o0($ooo0o0o0($o00o,0,$$ooo00oo00),'',$o00o),0,-2);eval($ooo000($ooo00o($o00o)));
/*@Zend;
3272;
print "<html><body>\n";
print "<a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\"><img border=\"0\" src=\"http://www.zend.com/images/store/safeguard_icon_nover_64.jpg\" align=\"right\"></a>\n";
print "<center><h1>Zend Optimizer not installed</h1></center>";
print "<p>This file was encoded by the <a href=\"http://www.zend.com/store/products/zend-encoder.php\">Zend Encoder</a> / <a href=\"http://www.zend.com/store/products/zend-safeguard-suite.php\">Zend SafeGuard Suite</a></p>\n";
print "<p>In order to run it, please install the freely available <a href=\"http://www.zend.com/store/products/zend-optimizer.php\">Zend Optimizer</a>, version 2.1.0 or later.</p>\n";
print "<h2>What is the Zend Optimizer?</h2>
";
print <<<EOM
<p>The Zend Optimizer is one of the most popular PHP plugins for performance-improvement, and has been freely available since the early days of PHP 4.  It improves performance by taking PHP's intermediate code through multiple Optimization Passes, which replace inefficient code patterns with efficient code blocks.  The replacement code blocks perform exactly the same operations as the original code, only faster.</p>
<p>In addition to performance-improvement, the Zend Optimizer also enables PHP to transparently load files encoded by the Zend Encoder or Zend SafeGuard Suite.</p>
<p>The Zend Optimizer is a freely-available product from <a href="http://www.zend.com">Zend Technologies</a>.  Zend Technologies is the company that develops the scripting engine of PHP, also known as the <a href="http://www.zend.com/store/products/zend-engine.php">Zend Engine</a>.</p>
EOM;
print "</body></html>\n";
exit();
?>2003120701 1 6690 25523 x??pVXNattAEL4b/A4bMOy62BGk9OKQQEkLvQXaXkoaHFk7robIK3V3FQeC76VP0BwKOaTHHgqFHnroy9SlfYuOVnIj26ukwXvRane+mW9+PqndardwzMSWhDEqkII/Pzx8ybvddovRgnO0gh+E6jW37HEUgTFsi3d3260oCWk/BTxHNQzlBBUZW1DSMPd20W6VLrJ8lGDEOnI0LK3ZHlN5kuwuDMa5iiymiqGiYN2L8rRYHRuj6e8vIWFaBRUFi8JqtuYolHIYuu2SuyLPsU6VHQyy1FBeJh9N0FKyrGblAhf3FK2ydq+7HpMjbtNTUPyYbI3VNs2zDLSYyEciV/gWpdChkqJLyw8nphYn4BzI0ILgr/qTvmTPBjgwfBWEY7Fakv6+hmiIyoC2wjldz8bFQ0kh1tElckhMV4O5ipb5axhrMLHIdSJ4iQyI+U6AMuDb5LrHrM5hLckZJAY8ZMKEYoLWqRb817fv8/dX8+svv79+Wkt4dvNa2wZBlccZwrS/71pAyXmqftuE7PhGpCwTKnsWJotZ6bwB6hRKflyn16F2hd6SkrlOp4JcLdnXKS+wxfM2jg83HGNfNuXgrabjzKuZzLLidmX8/503ggxEGqwfuLjzg1VYSWAZVx77IWkivSSrcz+o7JAXd3P1v5rLMydYh+8Vze56Jv0WASVoLN9AOD9/fJx//nAv4dxjummCNx1usmuc7Sg+tWDshhK8H0mI4tRhjngUQ3Rq8mip28W/rpFw0S0v22kMGogF53VmqZYa9vgJyhP25OmLA35XsRpyMKIM0OO8Vzrt8QdL3Q6Cs1APZT7JxJrj5u+fhGSz2jfKgjxDIQuPIO4QQ+BTg08JdRXM3139ubz2qGDWlDoUv4b6l7LKQ9MF/bs50uN8O4szXivf7C8=*/