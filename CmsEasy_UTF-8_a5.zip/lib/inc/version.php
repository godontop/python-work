<?php

define('_VERSION','6_0_0_20180228_UTF8');
define('_VERNUM','6.0.0.20180228');