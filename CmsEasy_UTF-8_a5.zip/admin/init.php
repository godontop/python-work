<?php

define('ADMIN',1);

define('ADMIN_DIR',preg_replace("%.*[\\\\/]%","",dirname(__FILE__)));
define('ADMIN_DIRNAME',dirname(__FILE__));

define('ADMIN_TEMPLATE',dirname(__FILE__).'/template');
