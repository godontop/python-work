<?php return array (


  array (
	'hrname' => '栏目/分页:{$dir}/{$page}.html',
    'htmlrule' => '{$dir}/{$page}.html',
    'cate' => 'category',
  ),

  array (
    'hrname' => '目录/目录/分页:{$caturl}/{$page}.html',
    'htmlrule' => '{$caturl}/{$page}.html',
    'cate' => 'category',
  ),

  array (
    'hrname' => '栏目/栏目_分页:{$caturl}_{$page}.html',
    'htmlrule' => '{$caturl}_{$page}.html',
    'cate' => 'category',
  ),

  array (
    'hrname' => '栏目_分页:{$dir}_{$page}.html',
    'htmlrule' => '{$dir}_{$page}.html',
    'cate' => 'category',
  ),
    array (
        'hrname' => '目录_ID_分页:{$dir}_{$catid}_{$page}.html',
        'htmlrule' => '{$dir}_{$catid}_{$page}.html',
        'cate' => 'category',
    ),
    array (

        'hrname' => '单页栏目:{$dir}.html',
        'htmlrule' => '{$dir}.html',
        'cate' => 'category',
    ),

    array (
    'hrname' => 'Show_ID_分页:show_{$aid}_{$page}.html',
    'htmlrule' => 'show_{$aid}_{$page}.html',
    'cate' => 'archive',
  ),

  array (
    'hrname' => '栏目_Show_ID_分页:{$dir}_show_{$aid}_{$page}.html',
    'htmlrule' => '{$dir}_show_{$aid}_{$page}.html',
    'cate' => 'archive',
  ),

  array (
    'hrname' => '目录/目录_Show_ID_分页:{$caturl}/show_{$aid}_{$page}.html',
    'htmlrule' => '{$caturl}/show_{$aid}_{$page}.html',
    'cate' => 'archive',
  ),

  array (
    'hrname' => '栏目_Show_ID_分页:{$dir}/show_{$aid}_{$page}.html',
    'htmlrule' => '{$dir}_show_{$aid}_{$page}.html',
    'cate' => 'archive',
  ),


);