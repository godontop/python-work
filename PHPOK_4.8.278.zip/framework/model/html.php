<?php
/*****************************************************************************************
	文件： {phpok}/model/html.php
	备注： HTML生成基础类
	版本： 4.x
	网站： www.phpok.com
	作者： qinggan <qinggan@188.com>
	时间： 2015年02月03日 11时28分
*****************************************************************************************/
if(!defined("PHPOK_SET")){exit("<h1>Access Denied</h1>");}
class html_model_base extends phpok_model
{
	public function __construct()
	{
		parent::model();
	}

}